function [ output ] = size_H( indc )


end

